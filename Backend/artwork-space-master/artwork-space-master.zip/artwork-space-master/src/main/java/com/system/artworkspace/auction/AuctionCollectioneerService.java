package com.system.artworkspace.auction;

import com.system.artworkspace.artwork.Artwork;
import com.system.artworkspace.artwork.ArtworkDto;

import java.util.List;

public interface AuctionCollectioneerService {
    List<Auction> getAvailableAuctions();

    Auction placeBid(Long id, double bidAmount);

    double getCurrentBid(Long id);

    Artwork getArtworkFromAuction (Long id);

    Auction getAuctionByPaintingId(Long paintingId);
}
