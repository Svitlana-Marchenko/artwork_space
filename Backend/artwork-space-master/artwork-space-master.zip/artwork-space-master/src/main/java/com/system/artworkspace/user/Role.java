package com.system.artworkspace.user;

public enum Role {
    ARTIST,
    CURATOR,
    COLLECTIONEER
}
